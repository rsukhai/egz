package com.example.egzam.data

import retrofit2.http.GET
import retrofit2.http.Query

data class JokeResponse(
    val joke: String?,       // для single-line жартів
    val setup: String?,      // для 2-part
    val delivery: String?,   // для 2-part
    val type: String         // "single" або "twopart"
)

interface JokeApiService {
    @GET("joke/Any")
    suspend fun getJokeByCategory(
        @Query("type") type: String = "any",      // опціонально
        @Query("category") category: String       // ми будемо підставляти категорії (Programming, Dark і т.д.)
    ): JokeResponse
}